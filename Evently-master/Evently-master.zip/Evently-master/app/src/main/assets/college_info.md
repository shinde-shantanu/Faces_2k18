<center><img src="https://static-collegedunia.com/public/college_data/images/appImage/13473_FCRIT_New.jpg" width="320dp"/></center>
## <center>About FCRIT</center>
<p style="text-align:justify">Fr. C. Rodrigues institute of Technology was established in  as an extension of the pioneering efforts of the Agnel Ashram fathers, in the arena of Technical Education with the relentless pursuit of excellence as its guiding force. F.C.R.l.T, in a short span of time established itself as a leading Engineering college in Mumbai, bagging at least one university 1st rank every year starting with its first graduating batch.</p>


<p style="text-align:justify">It has also made its mark in sports, extra-curricular and co-curricular activities. Government of Maharashtra awarded F.C.R.I.T.  an A grade in its first assessment.</p>