###HAKUNA MATATA? -
What a wonderful phrase !
Hakuna Matata! Ain’t no passing craze
It means no worries For the rest of your days It’s our problem free philosophy Hakuna Matata !
By Pumba and Timon FACES has been a host to a mixture of events forpast 24 years. As we enter our
25th iteration we wish to incorporate a silver lining to our cloud and make the few days of
our busy life trouble f ree.This FACES we present to you HAKUNA MATATA days of our life.
HAKUNA MATATA is a way t o approach life. It tells us to live freely, and enjoy every minute of
life rather than worrying about things. HAKUNA MATATA is a phrase that all of us students have
been listening to throughout our childhood, evoking a strong feeling of nostalgia. This time we
have included as much inputs we could get from the entire college, so that we could mold the events
to cater to everyone’s needs. We have many sports and cultural events to bring students from all
branches together, and promote the spirit of sportsmanship and we aim to develop each of our
students holistically so that challenges they might face in events prepare them to tackle their
future. With improved and engaging events we encourage our college youth to actively participate
in fun and healthy events.We’ve have crafted each event meticulously, so that everyone can
participate, and there will be “no worries” since we have included a plethora of opportunities
throughout FACES. This year FACES promises to be an ode to the stress free days of childhood.