## <h1><center>ABOUT FACES</h1></center>
<p style="text-align:justify">FACES or Father Agnel Cultural and Sports Events is an intra-college event and a platform for the youth to showcase their talents,with many
fun-filled cultural and entertaining sporting encounters. In providing all the events with
                              thorough organisation and maximum student participation we have
                              strived well for our excellence.We wish to continue a high level of
                              entertainment in our patient care and organised events.
                              FACES is a 3-day event. This year the days are 10,11,12th of September
                              which are Monday, Tuesday and Wednesday respectively.
                              This year is the Silver Jubilee of our most entertained and loved event.</br>
                             <h2><center>DAY 1</center></h2>
                             Starting with a bang FACES will celebrate its first day as MISMATCH DAY.One of the most mis-matched person will be chosen as the icon.</br></br>
                               <h2><center> DAY 2</h2></center>
                             The second day will follow the JERSEY DAY.Students are requested to wear the official college jersey.</br>
                          <center><h2>DAY 3</center></h2>
                               The third day will be celebrated as the TRADITIONAL DAY and everybody is expected to be in traditional wear.</br></br>
                              <h2><center>EVENTS</center></h2></br>
                             <h3> <center>A)Cultural<cenetr></h3>
<center >Inauguration</br>
Quizopia</br>
Start with 50</br>
THE ONE WO(MAN) SHOW</br>
Solo Dance</br>
Group Dance</br>
Debate</br>
Mock CID</br>
Solo Singing</br>
Duet/Group Singing</br>
Instrumental</br>
Band Event</br>
Convince Me</br>
Virtual Stock</br>
Traditional Walk</br>
Minute To Win It</br>
Content Writing</br>
House</br>
DJ</br></br>
<h3>B)Sports</h3>
Football</br>
Table Tennis(Singles)</br>
Table Tennis(Doubles)</br>
Basketball</br>
Kho-Kho</br>
Kabaddi</br>
100M & 400M</br>
Box Cricket</br>
Badminton(Singles)</br>
Badminton(Doubles)</br>
Swimming(Solo)</br>
Swimming(Relay)</br>
Tug Of War</br>
Throwball</br>
Dodgeball</br>
Volleyball</br>
Foot-Tennis</br>
Carrom(Singles)</br>
Carrom(Doubles)</br>
Chess</center></br></br></p>





<p style="text-align:justify">We invite you to share our vision and be a part of the legacy that carries forward excellence in every field.</p>

### <center><h1>HAKUNA MATATA?</center></h1>

<p>What a wonderful phrase !</p>
<p>Hakuna Matata!</p>
<p>Ain’t no passing craze</p>

<p>It means no worries For the rest of your days It’s our problem free philosophy Hakuna Matata !
By Pumba and Timon FACES has been a host to a mixture of events forpast 24 years. As we enter our
25th iteration we wish to incorporate a silver lining to our cloud and make the few days of
our busy life trouble f ree.This FACES we present to you HAKUNA MATATA days of our life.</p
<p>HAKUNA MATATA is a way to approach life. It tells us to live freely, and enjoy every minute of
life rather than worrying about things. HAKUNA MATATA is a phrase that all of us students have
been listening to throughout our childhood, evoking a strong feeling of nostalgia.</p>

<p>This time we have included as much inputs we could get from the entire college, so that we could
mold the events to cater to everyone’s needs. We have many sports and cultural events to bring
students from all branches together, and promote the spirit of sportsmanship and we aim to develop
each of our students holistically so that challenges they might face in events prepare them to
tackle their future. With improved and engaging events we encourage our college youth to actively
participate in fun and healthy events.We’ve have crafted each event meticulously, so that everyone
can participate, and there will be “no worries” since we have included a plethora of opportunities
throughout FACES. This year FACES promises to be an ode to the stress free days of childhood.</p>

<center><h2>DEV TEAM</h2>
<h3>Dylan Dsouza</h3>
<h4>Sem 7,Comps</h4>
<h3>Siddhesh Deshpande</h3>
<h4>Sem 5,Comps</h4>
<h3>Shantanu Shinde</h3>
<h4>Sem 5,Comps</h4>
<h3>Animesh Srivastava<h3/>
<h4>Sem 5,Comps</h4>
</center>
